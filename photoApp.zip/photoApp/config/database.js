// config/database.js
module.exports = {

    'url' : 'mongodb+srv://devchow:devchow@cluster0.julzg.mongodb.net/photoApp?retryWrites=true&w=majority', 
    'dbName': 'post'
};
